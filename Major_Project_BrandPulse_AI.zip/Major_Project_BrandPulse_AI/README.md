# BrandPulse AI — Sentiment Analysis on Twitter Data (NLP)
## Major Project Final Submission & Technical Documentation

---

## 1. Project Directory Structure

```
Major_Project_BrandPulse_AI/
├── Presentation/
│   └── BrandPulse_AI_Major_Project.pptx   # Executive 10-Slide PowerPoint Presentation Deck
├── Reports_and_Documentation/
│   ├── BrandPulse_AI_Major_Project_Report.pdf  # Formal Technical Report (PDF format)
│   ├── performance_report.md             # Markdown Performance Benchmark Report
│   ├── reverse_engineering_report.md     # Reverse Engineering & Probing Audit Report
│   ├── confusion_matrix_classical.png    # Classical Model Confusion Matrix Visual
│   └── confusion_matrix_lstm.png         # Deep Learning BiLSTM Confusion Matrix Visual
├── Live_Link/
│   ├── LIVE_DEMO_LINKS.md                # Direct URLs & Instructions to run the application
│   └── interactive_dashboard.html        # Zero-dependency interactive web demo (open in any browser)
├── Notebooks/
│   ├── 01_Preprocessing_and_Classical.ipynb # Preprocessing, Lemmatization, TF-IDF, LogReg
│   └── 02_Deep_Learning_LSTM.ipynb          # Tokenizer, Sequences, Word Embedding, BiLSTM
├── Source_Code/
│   ├── app.py                            # Streamlit Web Application (Live Feed, Donut, Trend Line)
│   ├── train_all.py                      # Complete end-to-end model training script
│   ├── src/
│   │   ├── preprocess.py                 # Text normalization, noise removal, lemmatization
│   │   ├── classical_model.py            # TF-IDF & Logistic Regression with Explainable AI
│   │   ├── deep_learning_lstm.py         # PyTorch Bi-Directional LSTM Neural Network
│   │   ├── reverse_engineering.py        # Parameter weights, occlusion, adversarial probes
│   │   ├── backprop_and_bootstrap.py     # Backpropagation saliency & 95% Bootstrap CI
│   │   └── selective_rag.py              # IBM-style retrieval gate for hallucination reduction
│   └── tests/
│       └── test_model_pipeline.py        # Automated unit test suite (100% Passed)
├── Models/
│   ├── tfidf_vectorizer.joblib           # Fitted TF-IDF 5,000-feature vocabulary
│   ├── logistic_regression.joblib        # Trained Logistic Regression model weights
│   ├── lstm_tokenizer.json               # Word-to-index tokenizer configuration
│   ├── lstm_config.json                  # Neural network architecture parameters
│   └── bilstm_weights.pt                 # PyTorch BiLSTM neural checkpoint weights
├── Dataset/
│   └── cleaned_tweets.csv                # Sanitized & lemmatized corpus (14,618 tweets)
└── README.md                             # Project overview and reproduction instructions
```

---

## 2. Executive Performance Summary

| Evaluation Dimension | Approach A: Classical NLP (TF-IDF + LogReg) | Approach B: Deep Learning (BiLSTM) | Assessment |
| :--- | :---: | :---: | :--- |
| **Test Accuracy** | **77.15%** | **72.78%** | Classical has higher overall keyword accuracy (+4.37%) |
| **Macro F1-Score** | **0.7216** | **0.6905** | High balance across all 3 imbalanced classes |
| **Weighted F1-Score** | **0.7773** | **0.7399** | Reflects heavy weighting of the dominant negative class |
| **Inference Latency** | **~1.1 ms** / tweet | **~14.8 ms** / tweet | Classical is **~13x faster** for real-time live feeds |
| **Model File Size** | **~205 KB** | **~2.5 MB** | Classical is ultra-compact for edge microservices |
| **Interpretability** | **100% Transparent** (Feature Weights) | **Black-Box** (Recurrent Gates) | Classical allows auditing individual word weights |
| **Context & Negation** | Limited to 2-word n-gram window | **Full Sequential Memory** | BiLSTM captures long-distance negations |

---

## 3. Required Test Cases Verification

Both models were verified on the required test scenarios:
* *"The service was amazing!"* $\to$ **POSITIVE** (97.8% Classical / 99.1% BiLSTM)
* *"I waited 4 hours just to get a cold burger."* $\to$ **NEGATIVE** (83.2% Classical / 89.5% BiLSTM)
* *"Flight 402 is delayed by 30 mins due to weather."* $\to$ **NEGATIVE** (84.7% Classical / 61.9% BiLSTM)
* *"Not happy with rude agent at baggage claim, worst experience."* $\to$ **NEGATIVE** (97.8% Classical / 100.0% BiLSTM)
* *"Thank you @VirginAmerica for a wonderfully smooth flight!"* $\to$ **POSITIVE** (90.1% Classical / 98.8% BiLSTM)

---

## 4. How to Run the Project

### A. Live Interactive Browser Demo (Zero Setup)
Open [`Live_Link/interactive_dashboard.html`](file:///Users/dama.praveen/.gemini/antigravity/scratch/Major_Project_BrandPulse_AI/Live_Link/interactive_dashboard.html) directly in any web browser.

### B. Live Streamlit Application
```bash
cd Source_Code
python3 -m streamlit run app.py
```
Open [http://localhost:8501](http://localhost:8501) in your browser.

### C. Run the Test Suite
```bash
cd Source_Code
python3 -m unittest tests/test_model_pipeline.py
```
*(All 8 unit tests pass in ~1.0s)*
