# BrandPulse AI: Reverse Engineering & Model Probing Report
**Behavioral Stress-Testing, Weight Deconstruction & Vulnerability Audit**

---

## 1. Executive Summary

Reverse engineering transforms a machine learning model from an opaque "black box" into an auditable, transparent decision engine. Using the **CheckList Methodology** and **Model Probing**, we reverse-engineered both the **Classical Model (TF-IDF + Logistic Regression)** and the **Deep Learning Model (Bi-Directional LSTM)** across 5 critical dimensions:
1. **Mathematical Parameter Extraction**: Finding the exact words that drive sentiment.
2. **Word Occlusion Sensitivity**: Measuring confidence drops when words are deleted.
3. **Adversarial Single-Word Flips**: Testing how easily the classifier can be fooled.
4. **Behavioral Stress Probes**: Testing Sarcasm, Negation, Typos, and Polite Complaints.
5. **Algorithmic Fairness Audit**: Probing brand-name handles for systemic bias.

---

## 2. Parameter Deconstruction (What Did the AI Learn?)

The model's decision function is governed by linear weights $W$:
$$\hat{y} = \text{argmax}_c \left( \sum_{i=1}^V w_{c, i} \cdot x_i + b_c \right)$$

Extracting the highest positive coefficients from the trained weight matrix:

| Class | Top Learned Keywords & Their Weights | What This Proves |
| :--- | :--- | :--- |
| **Negative** | `hour (+4.433)`, `worst (+3.575)`, `not (+3.573)`, `no (+3.318)`, `bag (+3.250)`, `delay (+2.980)` | Delays and luggage are the dominant complaint features |
| **Neutral** | `carry (+2.097)`, `delay cancel (+1.858)`, `hi (+1.763)`, `policy (+1.664)`, `dm (+1.620)` | Informational travel policy questions form the neutral cluster |
| **Positive** | `thank (+5.476)`, `great (+4.977)`, `awesome (+4.243)`, `amaze (+3.828)`, `love (+3.741)` | Appreciation keywords overpower almost all other signals |

---

## 3. Word Occlusion Sensitivity (LIME-style Ablation)

We systematically omitted individual words from customer sentences to measure the sensitivity $\Delta P$:
$$\Delta P = P(Y = \hat{y} \mid \text{Full Sentence}) - P(Y = \hat{y} \mid \text{Omitted Sentence})$$

### Test Case 1: Complex Mixed Review
> *"Thanks for the amazing crew but my bag was lost and the wait was terrible"*
* **Baseline Verdict**: **POSITIVE (71%)**
* **Occluding `'Thanks'`**: Confidence drops by **$-49\%$**
* **Occluding `'amazing'`**: Confidence drops by **$-38\%$**
* **Occluding `'crew'`**: Confidence drops by **$-10\%$**
* **Conclusion**: Even with negative clauses (*"bag was lost"*, *"wait was terrible"*), the model's decision was disproportionately driven by the single greeting word `"Thanks"`.

---

## 4. Adversarial Attack Simulator (The 1-Word Flips)

We probed how vulnerable the model is to intentional keyword manipulation:

* **Complaint 1**: *"my flight was delayed and nobody helped"* $\to$ **Negative (85%)**
  * Appending `"great"` $\to$ **Positive (52%)** ⚠️ Flipped!
  * Appending `"awesome"` $\to$ **Positive (49%)** ⚠️ Flipped!
  * Appending `"thanks"` $\to$ **Positive (48%)** ⚠️ Flipped!
* **Complaint 2**: *"lost my bag again"* $\to$ **Negative (98%)**
  * Appending `"thanks"` $\to$ **Positive (46%)** ⚠️ Flipped!

---

## 5. The 12 Behavioral Stress Tests (Classical vs LSTM)

| Probe Category | Input Test Tweet | Classical (LR) | Deep Learning (LSTM) | Finding / Engineering Takeaway |
| :--- | :--- | :---: | :---: | :--- |
| **Plain Positive** | *"The flight was great"* | **POS (0.92)** | **POS (0.89)** | Both models classify clear praise easily |
| **Negated Positive** | *"The flight was not great"* | **POS (0.65)** ❌ | **POS (0.83)** ❌ | **Negation Flaw**: `"great"` dominates `"not"` |
| **Negation + Never** | *"I will never fly with you again"* | **NEG (0.80)** | **NEG (0.56)** | Successfully learns `"never"` as negative signal |
| **Typo / Misspelling** | *"The service was terible"* | **NEG (0.61)** | **POS (0.56)** ❌ | BiLSTM tokenizer fails on out-of-vocab typos |
| **ALL CAPS** | *"THE SERVICE WAS AMAZING"* | **POS (0.97)** | **POS (0.90)** | Invariant to casing due to lowercase normalization |
| **Sarcasm (Subtle)** | *"Oh great, another delayed flight"* | **POS (0.51)** ❌ | **POS (0.74)** ❌ | Both models are tricked by sarcasm |
| **Sarcasm (Tarmac)** | *"Love waiting 5 hours on the tarmac"* | **NEG (0.68)** | **NEG (0.80)** | BiLSTM contextualizes `"waiting 5 hours"` |
| **Factual Inquiry** | *"Does the flight include a meal?"* | **NEU (0.86)** | **NEU (0.88)** | Strong neutral detection on question syntax |
| **Polite Complaint** | *"Unfortunately my bag did not arrive"* | **NEG (0.84)** | **NEG (0.66)** | Correctly detects complaint despite polite tone |

---

## 6. Algorithmic Fairness & Brand Bias Audit

* **Hypothesis**: Does the model inherently favor or penalize certain airline brands simply because of their handle name?
* **Experiment**: Tested identical neutral and complaint templates across `@united`, `@Delta`, `@SouthwestAir`, `@VirginAmerica`, `@AmericanAir`, and `@USAirways`.
* **Result**: All 6 airlines yielded identical predictions across all test sentences (**100% Brand Fairness**).

---

## 7. How to Access the Live Suite

1. **In the Streamlit Web App**:
   👉 Go to **[http://127.0.0.1:8501](http://127.0.0.1:8501)** $\to$ Click on the tab **"🕵️ Reverse Engineering & Probing"**.
2. **In the Standalone Browser File**:
   👉 Open [demo_dashboard.html](file:///Users/dama.praveen/.gemini/antigravity/brain/56b34a42-24ca-42ee-86a3-82fefd7cc3b2/demo_dashboard.html).
3. **CLI Execution**:
   ```bash
   cd /Users/dama.praveen/.gemini/antigravity/scratch/brandpulse_ai
   PYTHONPATH=./packages:. python3 src/reverse_engineering.py
   ```
