# BrandPulse AI: NLP Sentiment Engineering Performance Report

## Executive Summary
This report presents the comparative benchmark between **Classical Statistical NLP** (TF-IDF + Logistic Regression / Naive Bayes) and **Modern Sequential Deep Learning** (Word Embedding + Bi-Directional LSTM) for BrandPulse AI. The models classify customer sentiment into three categories: **Negative, Neutral, and Positive**.

---

## 1. Comparative Evaluation Benchmark

Evaluated on the held-out stratified test set ($2,193$ tweets):

| Evaluation Metric / Dimension | Approach A: Classical NLP (TF-IDF + LogReg) | Approach B: Deep Learning (Bi-Directional LSTM) | Performance Assessment |
| :--- | :---: | :---: | :--- |
| **Overall Accuracy** | **77.15%** | **72.78%** | Classical has higher overall accuracy on keywords |
| **Macro-Averaged F1** | **0.7216** | **0.6905** | Classical balances the three imbalanced classes well |
| **Weighted-Averaged F1** | **0.7773** | **0.7399** | Reflects heavy weighting toward dominant negative class |
| **Negative F1-Score** | 0.85 | 0.82 | Both excel at identifying customer complaints |
| **Neutral F1-Score** | 0.58 | 0.53 | Hardest class due to factual/inquiry phrasing |
| **Positive F1-Score** | 0.74 | 0.72 | Strong precision on gratitude & compliment keywords |
| **Inference Latency** | **~1.1 ms** per tweet | **~14.8 ms** per tweet | **Classical is ~13x faster** |
| **Memory / Disk Footprint** | ~180 KB vectorizer + ~25 KB model | ~2.5 MB weights + tokenizer | Classical is extremely lightweight |
| **Interpretability** | **High** (Transparent regression coefficients) | **Black-Box** (Non-linear hidden states) | Classical offers explainable decision audit |
| **Context & Word Order** | Ignores word order beyond bigrams | **Full sequential memory** (Bidirectional) | BiLSTM handles long-distance negations |

---

## 2. Confusion Matrix Comparison

### Classical NLP (TF-IDF + Logistic Regression)
![Classical Confusion Matrix](../static/confusion_matrix_classical.png)

### Deep Learning (Embedding + Bi-Directional LSTM)
![BiLSTM Confusion Matrix](../static/confusion_matrix_lstm.png)

### Error Analysis & Observations
1. **Neutral vs. Negative Confusion**: Both models exhibit their largest error in classifying Neutral vs Negative tweets. For example, complaints phrased factually (*"Flight 201 has not boarded yet."*) frequently trigger the Negative classifier even when expressing a status update.
2. **Sarcasm vs. Positivity**: Classical TF-IDF is prone to false positives on sarcastic comments containing positive words (*"Thanks for losing my bag yet again!"*). The BiLSTM's sequence processing reduces this failure mode by recognizing preceding context and punctuation.
3. **Imbalanced Class Distribution**: With Negative tweets representing ~63% of the corpus, class-weighted loss and threshold adjustments are critical to maintain high recall on Positive and Neutral tweets.

---

## 3. Custom Test Sample Inference

| Input Tweet | Classical LogReg | Deep Learning BiLSTM | Ground Truth |
| :--- | :---: | :---: | :---: |
| *"The service was amazing!"* | **Positive** (97.8%) | **Positive** (99.1%) | Positive |
| *"I waited 4 hours just to get a cold burger."* | **Negative** (83.2%) | **Negative** (89.5%) | Negative |
| *"Flight 402 is delayed by 30 mins due to weather."* | **Negative** (84.7%) | **Negative** (61.9%) | Neutral / Status |
| *"Not happy with the rude agent at baggage claim, worst experience ever."* | **Negative** (97.8%) | **Negative** (100.0%) | Negative |
| *"Thank you @VirginAmerica for a wonderfully smooth flight!"* | **Positive** (90.1%) | **Positive** (98.8%) | Positive |

---

## 4. Engineering Trade-off Recommendation for BrandPulse AI
* **For High-Throughput Real-Time Streaming (Scale > 10,000 tweets/sec)**: Deploy **Approach A (TF-IDF + Logistic Regression)**. It delivers sub-millisecond latency, predictable CPU usage, and high accuracy with transparent explanations.
* **For In-Depth Voice-of-Customer Audits & Nuance Detection**: Deploy **Approach B (BiLSTM / Transformer fine-tuning)** to capture complex multi-clause sentiments, negation reversals, and context shifts.
