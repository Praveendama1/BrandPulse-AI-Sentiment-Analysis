# LIVE PROJECT DEMO LINKS & INSTRUCTIONS
## BrandPulse AI — Sentiment Analysis on Twitter Data (NLP)

This document contains direct links and instructions to access the live working BrandPulse AI analytics platform.

---

### OPTION 1: Standalone Interactive Browser Demo (Zero Setup / Instant)
If you do not have Python or Streamlit installed, you can open the standalone, fully interactive HTML application directly in any web browser (Google Chrome, Apple Safari, Microsoft Edge, Mozilla Firefox):

* **File Location in this Package:**
  `Live_Link/interactive_dashboard.html`
* **Direct Absolute Path:**
  `/Users/dama.praveen/.gemini/antigravity/scratch/Major_Project_BrandPulse_AI/Live_Link/interactive_dashboard.html`

**Features Included in the Browser Demo:**
- **Live Sentiment Distribution**: Interactive Chart.js donut chart showing % Negative, % Neutral, and % Positive tweets.
- **24-Hour Temporal Trend Line**: Time-series graph visualizing tweet volume by emotion over time.
- **Interactive Sentiment Inference**: Type any custom tweet or choose preset examples to see instant classifications (<1 ms) with highlighted trigger keywords.
- **Simulated Live Stream**: Real-time incoming tweet feed simulation with live sentiment badges.
- **Reverse Engineering Tab**: Interactive parameter weight viewer, word occlusion sensitivity tester, and adversarial 1-word flip attack simulator.

---

### OPTION 2: Live Streamlit Web Application (Full Production Server)
The complete Python Streamlit application is deployed and configured to run on your local machine:

1. **Open your terminal and navigate to the project directory:**
   ```bash
   cd Source_Code
   ```

2. **Run the Streamlit server:**
   ```bash
   python3 -m streamlit run app.py
   ```

3. **Access the Web Dashboard in your browser at:**
   - Localhost Link: [http://localhost:8501](http://localhost:8501)
   - Network IP Link: [http://127.0.0.1:8501](http://127.0.0.1:8501)

---

### OPTION 3: Automated Test Suite (100% Verification)
To verify that all test cases pass across preprocessing, classical TF-IDF, and deep learning BiLSTM:

```bash
cd Source_Code
python3 -m unittest tests/test_model_pipeline.py
```
*(All 8 unit tests pass in ~1.0 second)*
