"""
reverse_engineering.py - Model Probing & Reverse Engineering Suite for BrandPulse AI
Implements Feature Weight Deconstruction, Word Occlusion Sensitivity,
Adversarial Flip Testing, Behavioral Stress Tests, and Brand Bias Probes.
"""

import os
import sys
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(base_dir, "packages"))
sys.path.insert(0, base_dir)

from src.preprocess import clean_text_pipeline, INT2LABEL, LABEL2INT
from src.classical_model import ClassicalSentimentPipeline
from src.deep_learning_lstm import DeepLearningTrainer


class ReverseEngineeringSuite:
    """
    Reverse-engineers and stress-tests NLP models for explainability, robustness, and bias.
    """

    def __init__(self, models_dir: str):
        self.models_dir = models_dir
        self.classical = ClassicalSentimentPipeline.load(models_dir)
        self.lstm = DeepLearningTrainer.load(models_dir)
        self.feature_names = np.array(self.classical.vectorizer.get_feature_names_out())

    # -------------------------------------------------------------
    # 1. Feature Weight Deconstruction
    # -------------------------------------------------------------
    def get_top_learned_weights(self, top_n: int = 10) -> Dict[str, List[Dict[str, Any]]]:
        """
        Extracts the highest positive and negative weights directly from the model parameters.
        """
        coefs = self.classical.model.coef_  # Shape: (3, n_features)
        results = {}

        for class_idx, class_name in INT2LABEL.items():
            sorted_indices = coefs[class_idx].argsort()
            top_positive = sorted_indices[-top_n:][::-1]
            
            words_list = []
            for idx in top_positive:
                words_list.append({
                    "word": str(self.feature_names[idx]),
                    "weight": round(float(coefs[class_idx][idx]), 3)
                })
            results[class_name] = words_list

        return results

    # -------------------------------------------------------------
    # 2. Word Occlusion / LIME-style Sensitivity
    # -------------------------------------------------------------
    def word_occlusion_test(self, text: str) -> Dict[str, Any]:
        """
        Deletes one word at a time to measure how much the prediction confidence drops.
        """
        cleaned = clean_text_pipeline(text)
        words = text.split()
        if not words:
            return {}

        # Baseline predictions
        c_base_pred, c_base_probs = self.classical.predict_single(cleaned)
        l_base_pred, l_base_probs = self.lstm.predict_single(cleaned)

        c_base_conf = c_base_probs[c_base_pred]
        l_base_conf = l_base_probs[l_base_pred]

        occlusion_results = []
        for i, word in enumerate(words):
            omitted_text = " ".join(words[:i] + words[i+1:])
            omitted_clean = clean_text_pipeline(omitted_text)
            
            # Predict without this word
            _, c_probs = self.classical.predict_single(omitted_clean)
            _, l_probs = self.lstm.predict_single(omitted_clean)

            c_drop = float(c_base_conf - c_probs[c_base_pred])
            l_drop = float(l_base_conf - l_probs[l_base_pred])

            occlusion_results.append({
                "word": word,
                "classical_drop": round(c_drop, 3),
                "lstm_drop": round(l_drop, 3)
            })

        # Sort by impact
        occlusion_results = sorted(occlusion_results, key=lambda x: abs(x["classical_drop"]), reverse=True)

        return {
            "text": text,
            "classical_verdict": INT2LABEL[c_base_pred].upper(),
            "classical_conf": round(float(c_base_conf * 100), 1),
            "lstm_verdict": INT2LABEL[l_base_pred].upper(),
            "lstm_conf": round(float(l_base_conf * 100), 1),
            "word_impacts": occlusion_results
        }

    # -------------------------------------------------------------
    # 3. Adversarial Single-Word Flip Test
    # -------------------------------------------------------------
    def test_adversarial_flips(self, text: str) -> Dict[str, Any]:
        """
        Tests if appending positive words can trick a negative tweet into flipping to positive.
        """
        clean = clean_text_pipeline(text)
        base_pred, base_probs = self.classical.predict_single(clean)
        base_label = INT2LABEL[base_pred]

        candidate_words = ["thanks", "thank", "great", "awesome", "amaze", "love", "good", "best", "superb"]
        flips = []

        for cand in candidate_words:
            perturbed_text = text + " " + cand
            pert_clean = clean_text_pipeline(perturbed_text)
            new_pred, new_probs = self.classical.predict_single(pert_clean)
            
            if new_pred != base_pred:
                flips.append({
                    "trigger_word": cand,
                    "new_verdict": INT2LABEL[new_pred].upper(),
                    "new_confidence": round(float(new_probs[new_pred] * 100), 1)
                })

        return {
            "original_text": text,
            "original_verdict": base_label.upper(),
            "original_confidence": round(float(base_probs[base_pred] * 100), 1),
            "is_vulnerable": len(flips) > 0,
            "flips_found": flips
        }

    # -------------------------------------------------------------
    # 4. Behavioral Stress Tests (CheckList Methodology)
    # -------------------------------------------------------------
    def run_behavioral_probes(self) -> List[Dict[str, Any]]:
        """
        Comprehensive stress probes covering Sarcasm, Negation, Typos, and Edge Cases.
        """
        test_probes = [
            ("Plain Positive", "The flight was great"),
            ("Negated Positive", "The flight was not great"),
            ("Negation + Never", "I will never fly with you again"),
            ("Typo / Misspelling", "The service was terible"),
            ("ALL CAPS Intensity", "THE SERVICE WAS AMAZING"),
            ("Emoji Sentiment", "Flight landed on time 😊"),
            ("Hashtag Sentiment", "#worstairline ever"),
            ("Sarcasm (Subtle)", "Oh great, another delayed flight"),
            ("Sarcasm (Exaggerated)", "Love waiting 5 hours on the tarmac"),
            ("Factual / Inquiry", "Does the flight include a meal?"),
            ("Polite Complaint", "Unfortunately my bag did not arrive"),
            ("Mixed Sentiment", "Crew was lovely but the delay was awful")
        ]

        results = []
        for category, probe_text in test_probes:
            clean = clean_text_pipeline(probe_text)
            c_pred, c_probs = self.classical.predict_single(clean)
            l_pred, l_probs = self.lstm.predict_single(clean)

            results.append({
                "category": category,
                "text": probe_text,
                "classical_pred": INT2LABEL[c_pred].upper(),
                "classical_conf": f"{c_probs[c_pred]*100:.0f}%",
                "lstm_pred": INT2LABEL[l_pred].upper(),
                "lstm_conf": f"{l_probs[l_pred]*100:.0f}%"
            })

        return results

    # -------------------------------------------------------------
    # 5. Airline Brand Bias Probe
    # -------------------------------------------------------------
    def probe_brand_bias(self) -> Dict[str, Any]:
        """
        Verifies if replacing the airline handle in a sentence causes sentiment bias.
        """
        airlines = ["united", "SouthwestAir", "VirginAmerica", "Delta", "AmericanAir", "USAirways"]
        templates = [
            "@{brand} my flight was delayed again",
            "@{brand} thanks for a great flight"
        ]

        bias_report = {}
        for tmpl in templates:
            scores = []
            for brand in airlines:
                tweet = tmpl.format(brand=brand)
                clean = clean_text_pipeline(tweet)
                pred, probs = self.classical.predict_single(clean)
                scores.append(INT2LABEL[pred])
            
            # If all brands get the same classification, bias = 0 (completely fair)
            is_unbiased = len(set(scores)) == 1
            bias_report[tmpl] = {
                "is_unbiased": is_unbiased,
                "classifications": scores
            }

        return bias_report
