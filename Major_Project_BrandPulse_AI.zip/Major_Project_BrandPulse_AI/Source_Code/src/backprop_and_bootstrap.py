"""
backprop_and_bootstrap.py - Backpropagation Saliency & Statistical Bootstrapping Suite
1. Backpropagation: Computes gradient attribution (dL/dx) through the BiLSTM neural network.
2. Bootstrapping: Computes 95% Confidence Intervals (B=1000) for model accuracy and F1 scores.
"""

import os
import sys
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(base_dir, "packages"))
sys.path.insert(0, base_dir)

import torch
from src.preprocess import clean_text_pipeline, INT2LABEL, LABEL2INT
from src.classical_model import ClassicalSentimentPipeline
from src.deep_learning_lstm import DeepLearningTrainer


class BackpropagationExplainer:
    """
    Leverages PyTorch Backpropagation to compute exact gradient attribution (dL/dEmbedding)
    for every word in a tweet.
    """
    def __init__(self, models_dir: str):
        self.trainer = DeepLearningTrainer.load(models_dir)
        self.model = self.trainer.model
        self.tokenizer = self.trainer.tokenizer

    def compute_backprop_saliency(self, text: str) -> Dict[str, Any]:
        """
        Runs a forward pass, computes the loss with respect to the predicted class,
        and executes loss.backward() to compute the gradient norm for each token.
        """
        cleaned = clean_text_pipeline(text)
        words = cleaned.split()
        if not words:
            return {"text": text, "words": [], "saliencies": []}

        seq = self.tokenizer.pad_sequences(self.tokenizer.texts_to_sequences([cleaned]))
        tensor_seq = torch.tensor(seq, dtype=torch.long)

        # Enable gradient tracking on word embeddings
        self.model.zero_grad()
        embeds = self.model.embedding(tensor_seq)
        embeds.retain_grad()

        # Forward pass through spatial dropout, BiLSTM, pooling, and classifier
        embeds_p = embeds.permute(0, 2, 1).unsqueeze(3)
        embeds_p = self.model.spatial_dropout(embeds_p).squeeze(3).permute(0, 2, 1)
        lstm_out, _ = self.model.lstm(embeds_p)
        avg_pool = torch.mean(lstm_out, dim=1)
        max_pool, _ = torch.max(lstm_out, dim=1)
        pooled = torch.cat([avg_pool, max_pool], dim=1)
        logits = self.model.classifier(pooled)

        pred_class = torch.argmax(logits, dim=1).item()
        probs = torch.softmax(logits, dim=1).detach().numpy()[0]

        # BACKPROPAGATION: compute d(Logit_pred) / d(Embedding)
        logits[0, pred_class].backward()

        # Gradient magnitude for each word
        grad = embeds.grad.data[0]  # Shape: [max_len, embed_dim]
        grad_norms = torch.norm(grad, dim=1).numpy()

        word_attributions = []
        for i, word in enumerate(words):
            if i < len(grad_norms):
                word_attributions.append({
                    "word": word,
                    "gradient_norm": round(float(grad_norms[i]), 4)
                })

        # Normalize relative importance
        total_grad = sum(item["gradient_norm"] for item in word_attributions) or 1.0
        for item in word_attributions:
            item["relative_importance_pct"] = round((item["gradient_norm"] / total_grad) * 100, 1)

        word_attributions = sorted(word_attributions, key=lambda x: x["gradient_norm"], reverse=True)

        return {
            "text": text,
            "cleaned": cleaned,
            "predicted_class": INT2LABEL[pred_class].upper(),
            "confidence_pct": round(float(probs[pred_class] * 100), 1),
            "word_attributions": word_attributions
        }


class BootstrapEvaluator:
    """
    Performs Statistical Bootstrapping (resampling with replacement) to compute
    95% Confidence Intervals for Accuracy, Macro F1, and evaluate model robustness.
    """
    def __init__(self, n_bootstraps: int = 1000, random_state: int = 42):
        self.n_bootstraps = n_bootstraps
        self.random_state = random_state

    def compute_bootstrap_ci(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        metric_name: str = "Accuracy"
    ) -> Dict[str, Any]:
        """
        Draws B bootstrap samples with replacement and calculates 95% Confidence Intervals.
        """
        rng = np.random.RandomState(self.random_state)
        n_samples = len(y_true)
        boot_scores = []

        for _ in range(self.n_bootstraps):
            indices = rng.choice(n_samples, size=n_samples, replace=True)
            if metric_name.lower() == "accuracy":
                score = accuracy_score(y_true[indices], y_pred[indices])
            elif metric_name.lower() == "macro_f1":
                score = f1_score(y_true[indices], y_pred[indices], average="macro", zero_division=0)
            elif metric_name.lower() == "weighted_f1":
                score = f1_score(y_true[indices], y_pred[indices], average="weighted", zero_division=0)
            else:
                score = accuracy_score(y_true[indices], y_pred[indices])
            boot_scores.append(score)

        ci_lower = float(np.percentile(boot_scores, 2.5))
        ci_upper = float(np.percentile(boot_scores, 97.5))
        mean_score = float(np.mean(boot_scores))
        std_score = float(np.std(boot_scores))

        return {
            "metric": metric_name,
            "mean": round(mean_score, 4),
            "std": round(std_score, 4),
            "ci_95_lower": round(ci_lower, 4),
            "ci_95_upper": round(ci_upper, 4),
            "ci_str": f"{mean_score*100:.2f}% (95% CI: [{ci_lower*100:.2f}%, {ci_upper*100:.2f}%])"
        }


def main():
    print("====================================================================")
    print("     BRANDPULSE AI: BACKPROPAGATION SALIENCY & BOOTSTRAPPING       ")
    print("====================================================================")

    models_dir = os.path.join(base_dir, "models")
    data_path = os.path.join(base_dir, "data", "cleaned_tweets.csv")

    # 1. Backpropagation Demonstration
    print("\n--- 1. BACKPROPAGATION: Computing Neural Saliency Gradients ---")
    bp_explainer = BackpropagationExplainer(models_dir)
    
    test_sentences = [
        "The service was amazing but flight delayed.",
        "I waited 4 hours just to get a cold burger.",
        "Does the flight include a complimentary meal?"
    ]

    for sentence in test_sentences:
        res = bp_explainer.compute_backprop_saliency(sentence)
        print(f"\nTweet: \"{res['text']}\"")
        print(f" -> Predicted Class : {res['predicted_class']} ({res['confidence_pct']}%)")
        print(" -> Word Gradients via Backpropagation:")
        for item in res["word_attributions"]:
            print(f"    * '{item['word']}': Gradient Norm = {item['gradient_norm']:.4f} ({item['relative_importance_pct']}%)")

    # 2. Statistical Bootstrapping Demonstration
    print("\n--- 2. BOOTSTRAPPING: 95% Confidence Intervals (B = 1000 Resamples) ---")
    df = pd.read_csv(data_path)
    X = df["clean_text"]
    y = df["label"].values

    # Test split
    _, X_test, _, y_test = train_test_split(X, y, test_size=0.15, random_state=42, stratify=y)
    
    classical_pipe = ClassicalSentimentPipeline.load(models_dir)
    X_test_vec = classical_pipe.vectorizer.transform(X_test)
    y_pred_classical = classical_pipe.model.predict(X_test_vec)

    boot = BootstrapEvaluator(n_bootstraps=1000, random_state=42)
    acc_ci = boot.compute_bootstrap_ci(y_test, y_pred_classical, "Accuracy")
    macro_f1_ci = boot.compute_bootstrap_ci(y_test, y_pred_classical, "Macro_F1")
    weighted_f1_ci = boot.compute_bootstrap_ci(y_test, y_pred_classical, "Weighted_F1")

    print(f"Classical Model Accuracy : {acc_ci['ci_str']}")
    print(f"Classical Model Macro-F1 : {macro_f1_ci['ci_str']}")
    print(f"Classical Model Weighted-F1: {weighted_f1_ci['ci_str']}")
    print("\nConclusion: Statistical Bootstrapping proves model stability across 1,000 resamples!")


if __name__ == "__main__":
    main()
