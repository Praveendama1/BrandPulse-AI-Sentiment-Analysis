"""
rl_sentiment_agent.py - Reinforcement Learning (RL) Suite for BrandPulse AI
Demonstrates:
1. Contextual Bandit Policy Optimization (Multi-Armed Bandit for Active Sentiment Thresholding).
2. RLHF (Reinforcement Learning from Human Feedback) Environment for Brand Response Tuning.
3. Policy Gradient Update (REINFORCE) based on Customer Satisfaction Rewards.
"""

import os
import sys
import numpy as np
from typing import Dict, List, Tuple, Any

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(base_dir, "packages"))
sys.path.insert(0, base_dir)

from src.preprocess import clean_text_pipeline, INT2LABEL, LABEL2INT
from src.classical_model import ClassicalSentimentPipeline


class BrandActionSpace:
    """
    Action space for the Reinforcement Learning agent handling Twitter customer care.
    """
    ACTIONS = [
        "IMMEDIATE_ESCALATE_HUMAN",   # High-priority human supervisor intervention
        "ISSUE_COMPENSATION_POLICY",  # Issue refund/voucher rules directly
        "EMPATHETIC_APOLOGY",         # De-escalate with brand apology
        "STANDARD_INFO_REPLY",        # Neutral informational guidance
        "LOG_AND_IGNORE_NOISE"        # Casual noise / troll suppression
    ]


class RLAgentPolicy:
    """
    Policy Network for the Contextual Bandit RL Agent.
    Learns state-to-action probability distribution: pi(a | s) via Policy Gradients.
    """
    def __init__(self, state_dim: int = 5, num_actions: int = 5, lr: float = 0.05):
        self.state_dim = state_dim
        self.num_actions = num_actions
        self.lr = lr
        
        # Policy parameter weights: theta (state_dim x num_actions)
        # Initialized with sensible operational priors
        self.theta = np.zeros((state_dim, num_actions), dtype=np.float32)
        # Prior: Negative sentiment with high confidence leans toward escalation/apology
        self.theta[0, 0] = 1.5   # P(Negative) -> Escalate
        self.theta[0, 2] = 1.0   # P(Negative) -> Apology
        self.theta[1, 3] = 2.0   # P(Neutral) -> Standard Info
        self.theta[2, 4] = 2.0   # P(Positive) -> Log Noise

    def get_action_probabilities(self, state: np.ndarray) -> np.ndarray:
        """
        Softmax Policy: pi(a | s) = exp(s * theta_a) / sum(exp(s * theta))
        """
        logits = np.dot(state, self.theta)
        exp_logits = np.exp(logits - np.max(logits))
        return exp_logits / np.sum(exp_logits)

    def select_action(self, state: np.ndarray, deterministic: bool = False) -> Tuple[int, np.ndarray]:
        probs = self.get_action_probabilities(state)
        if deterministic:
            action = int(np.argmax(probs))
        else:
            action = int(np.random.choice(self.num_actions, p=probs))
        return action, probs

    def update_policy(self, state: np.ndarray, action: int, reward: float):
        """
        REINFORCE Policy Gradient Update:
        grad_theta = reward * (x - sum_a(pi(a|s) * x))
        theta <- theta + lr * grad_theta
        """
        probs = self.get_action_probabilities(state)
        # Compute gradient of log pi(a|s)
        grad = np.zeros_like(self.theta)
        for a in range(self.num_actions):
            indicator = 1.0 if a == action else 0.0
            grad[:, a] = state * (indicator - probs[a])

        # Policy update towards positive reward
        self.theta += self.lr * reward * grad


class CustomerSatisfactionRewardEnvironment:
    """
    Reward Function simulating Customer Satisfaction (CSAT) and Brand Retention.
    - Positive reward (+1.0 to +2.0): Successful de-escalation, accurate policy guidance.
    - Penalty (-1.0 to -3.0): Ignoring an angry customer or over-escalating trivial noise.
    """
    @staticmethod
    def calculate_reward(state: np.ndarray, action: int, customer_query: str) -> Tuple[float, str]:
        p_neg, p_neu, p_pos, urgency_flag, length_norm = state
        action_name = BrandActionSpace.ACTIONS[action]

        # Case 1: Severe complaint / angry customer
        if p_neg > 0.65 or urgency_flag > 0.5:
            if action_name == "IMMEDIATE_ESCALATE_HUMAN":
                return +2.0, "Optimal: Severe issue handled by human specialist (Customer retained)."
            elif action_name == "EMPATHETIC_APOLOGY":
                return +1.2, "Good: Quick apology eased frustration."
            elif action_name == "LOG_AND_IGNORE_NOISE":
                return -3.0, "CRITICAL ERROR: Ignored a viral PR disaster complaint!"
            else:
                return -0.5, "Suboptimal: Generic reply to a severe complaint."

        # Case 2: Neutral policy question
        elif p_neu > 0.5:
            if action_name in ["STANDARD_INFO_REPLY", "ISSUE_COMPENSATION_POLICY"]:
                return +1.8, "Optimal: Accurate, factual policy delivered instantly."
            elif action_name == "IMMEDIATE_ESCALATE_HUMAN":
                return -1.0, "Cost Penalty: Unnecessary human escalation for simple FAQ."
            else:
                return -1.5, "Poor: Failed to answer passenger inquiry."

        # Case 3: Positive feedback / praise
        else:
            if action_name == "LOG_AND_IGNORE_NOISE":
                return +1.0, "Efficient: Logged positive brand sentiment without overhead."
            elif action_name == "EMPATHETIC_APOLOGY":
                return -1.0, "Awkward: Apologized to a compliment!"
            else:
                return +0.5, "Acceptable response to positive feedback."


class BrandPulseRLSystem:
    """
    End-to-End Reinforcement Learning System:
    Extracts state from NLP models -> Selects action -> Evaluates Reward -> Updates Policy.
    """
    def __init__(self, models_dir: str):
        self.classical_pipe = ClassicalSentimentPipeline.load(models_dir)
        self.policy = RLAgentPolicy()
        self.env = CustomerSatisfactionRewardEnvironment()

    def construct_state(self, tweet_text: str) -> Tuple[np.ndarray, Dict[str, Any]]:
        clean = clean_text_pipeline(tweet_text)
        pred_idx, probs = self.classical_pipe.predict_single(clean)

        # State features:
        # [0] P(Negative), [1] P(Neutral), [2] P(Positive), [3] Urgency Flag, [4] Length feature
        urgency_keywords = ["urgent", "help", "emergency", "immediately", "stranded", "cancel", "stuck", "lost"]
        urgency_score = 1.0 if any(k in tweet_text.lower() for k in urgency_keywords) else 0.0
        length_norm = min(len(tweet_text.split()) / 30.0, 1.0)

        state = np.array([probs[0], probs[1], probs[2], urgency_score, length_norm], dtype=np.float32)
        
        info = {
            "probabilities": probs,
            "predicted_sentiment": INT2LABEL[pred_idx],
            "urgency": urgency_score > 0
        }
        return state, info

    def decide_and_learn(self, tweet_text: str, update_online: bool = True) -> Dict[str, Any]:
        state, info = self.construct_state(tweet_text)
        action_idx, action_probs = self.policy.select_action(state, deterministic=False)
        action_name = BrandActionSpace.ACTIONS[action_idx]

        reward, reward_feedback = self.env.calculate_reward(state, action_idx, tweet_text)

        if update_online:
            self.policy.update_policy(state, action_idx, reward)

        action_breakdown = {
            BrandActionSpace.ACTIONS[i]: round(float(action_probs[i]) * 100, 1)
            for i in range(len(BrandActionSpace.ACTIONS))
        }

        return {
            "tweet": tweet_text,
            "sentiment": info["predicted_sentiment"].upper(),
            "selected_action": action_name,
            "reward": reward,
            "feedback": reward_feedback,
            "action_probabilities": action_breakdown
        }


def main():
    print("====================================================================")
    print("        BRANDPULSE AI: REINFORCEMENT LEARNING (RL) PIPELINE        ")
    print("====================================================================")

    models_dir = os.path.join(base_dir, "models")
    rl_system = BrandPulseRLSystem(models_dir)

    test_queries = [
        "URGENT: Stranded at Chicago O'Hare with two infants, flight cancelled!",
        "What is the maximum allowed carry-on luggage size?",
        "Loved the smooth flight and the friendly crew! Thank you so much.",
        "Waited 5 hours on hold, lost luggage, worst customer support ever.",
        "Does flight 104 have in-seat charging ports?"
    ]

    for q in test_queries:
        res = rl_system.decide_and_learn(q, update_online=True)
        print(f"\nTweet: \"{res['tweet']}\"")
        print(f" -> Detected Sentiment : {res['sentiment']}")
        print(f" -> RL Chosen Action   : 🎯 {res['selected_action']}")
        print(f" -> Environment Reward : {res['reward']:+.1f} pts ({res['feedback']})")
        print(" -> Policy Distribution:")
        for act, pct in res["action_probabilities"].items():
            print(f"    * {act[:26]:26s}: {pct:.1f}%")

    print("\n[SUCCESS] Reinforcement Learning Agent active and policy gradients updated!")


if __name__ == "__main__":
    main()
