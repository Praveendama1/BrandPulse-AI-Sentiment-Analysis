"""
deep_learning_lstm.py - Deep Learning Bi-Directional LSTM Model for BrandPulse AI
Implements Tokenization, Sequence Padding, Word Embedding, BiLSTM, and Dense Classification.
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(base_dir, "packages"))

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score


class TextTokenizer:
    """
    Tokenizer that maps words to integer indices with PAD (0) and OOV/UNK (1) tokens.
    """
    def __init__(self, max_words: int = 8000, max_len: int = 60):
        self.max_words = max_words
        self.max_len = max_len
        self.word2idx = {"<PAD>": 0, "<UNK>": 1}
        self.idx2word = {0: "<PAD>", 1: "<UNK>"}
        self.word_counts = {}

    def fit_on_texts(self, texts: List[str]):
        counts = {}
        for text in texts:
            for word in text.split():
                counts[word] = counts.get(word, 0) + 1
        
        self.word_counts = counts
        sorted_words = sorted(counts.items(), key=lambda x: x[1], reverse=True)
        
        for idx, (word, _) in enumerate(sorted_words[: self.max_words - 2], start=2):
            self.word2idx[word] = idx
            self.idx2word[idx] = word

    def texts_to_sequences(self, texts: List[str]) -> List[List[int]]:
        sequences = []
        for text in texts:
            seq = [self.word2idx.get(w, 1) for w in text.split()]
            sequences.append(seq)
        return sequences

    def pad_sequences(self, sequences: List[List[int]]) -> np.ndarray:
        padded = np.zeros((len(sequences), self.max_len), dtype=np.int64)
        for i, seq in enumerate(sequences):
            if len(seq) > self.max_len:
                padded[i] = seq[: self.max_len]
            else:
                padded[i, : len(seq)] = seq
        return padded

    def save(self, filepath: str):
        data = {
            "max_words": self.max_words,
            "max_len": self.max_len,
            "word2idx": self.word2idx
        }
        with open(filepath, "w") as f:
            json.dump(data, f)

    @classmethod
    def load(cls, filepath: str):
        with open(filepath, "r") as f:
            data = json.load(f)
        tok = cls(max_words=data["max_words"], max_len=data["max_len"])
        tok.word2idx = data["word2idx"]
        tok.idx2word = {int(v): k for k, v in data["word2idx"].items()}
        return tok


class TweetDataset(Dataset):
    def __init__(self, sequences: np.ndarray, labels: Optional[np.ndarray] = None):
        self.sequences = torch.tensor(sequences, dtype=torch.long)
        self.labels = torch.tensor(labels, dtype=torch.long) if labels is not None else None

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        if self.labels is not None:
            return self.sequences[idx], self.labels[idx]
        return self.sequences[idx]


class BiLSTMSentimentClassifier(nn.Module):
    """
    Recurrent Neural Network Architecture:
    Embedding Layer -> Dropout -> Bi-Directional LSTM -> Max+Average Pooling -> Dense -> Softmax Output
    """
    def __init__(
        self,
        vocab_size: int,
        embed_dim: int = 128,
        hidden_dim: int = 128,
        num_layers: int = 1,
        num_classes: int = 3,
        dropout_rate: float = 0.3
    ):
        super(BiLSTMSentimentClassifier, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.spatial_dropout = nn.Dropout2d(dropout_rate)
        
        self.lstm = nn.LSTM(
            embed_dim,
            hidden_dim,
            num_layers=num_layers,
            bidirectional=True,
            batch_first=True,
            dropout=dropout_rate if num_layers > 1 else 0
        )
        
        # BiLSTM outputs hidden_dim * 2
        lstm_out_dim = hidden_dim * 2
        
        self.classifier = nn.Sequential(
            nn.Linear(lstm_out_dim * 2, 64),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        # x shape: [batch_size, seq_len]
        embeds = self.embedding(x)  # [batch_size, seq_len, embed_dim]
        
        # Spatial dropout on embedding channel
        embeds = embeds.permute(0, 2, 1).unsqueeze(3)
        embeds = self.spatial_dropout(embeds).squeeze(3).permute(0, 2, 1)
        
        # LSTM forward pass
        lstm_out, _ = self.lstm(embeds)  # [batch_size, seq_len, hidden_dim * 2]
        
        # Global Average Pooling & Global Max Pooling across sequence dimension
        avg_pool = torch.mean(lstm_out, dim=1)
        max_pool, _ = torch.max(lstm_out, dim=1)
        
        # Concatenate poolings
        pooled = torch.cat([avg_pool, max_pool], dim=1)  # [batch_size, lstm_out_dim * 2]
        
        logits = self.classifier(pooled)
        return logits


class DeepLearningTrainer:
    """
    Encapsulates training, validation, evaluation, and inference for the LSTM model.
    """
    def __init__(
        self,
        max_words: int = 8000,
        max_len: int = 60,
        embed_dim: int = 128,
        hidden_dim: int = 128,
        batch_size: int = 64,
        lr: float = 0.001,
        epochs: int = 10
    ):
        self.max_words = max_words
        self.max_len = max_len
        self.embed_dim = embed_dim
        self.hidden_dim = hidden_dim
        self.batch_size = batch_size
        self.lr = lr
        self.epochs = epochs
        
        self.device = torch.device("cpu")
        self.tokenizer = TextTokenizer(max_words=max_words, max_len=max_len)
        self.model: Optional[BiLSTMSentimentClassifier] = None

    def fit(self, train_texts: List[str], y_train: np.ndarray, val_texts: List[str], y_val: np.ndarray):
        print(f"Tokenizing vocabulary on {len(train_texts)} training texts...")
        self.tokenizer.fit_on_texts(train_texts)
        vocab_size = len(self.tokenizer.word2idx)
        print(f"Total vocabulary size: {vocab_size}")

        # Prepare datasets & dataloaders
        train_seqs = self.tokenizer.pad_sequences(self.tokenizer.texts_to_sequences(train_texts))
        val_seqs = self.tokenizer.pad_sequences(self.tokenizer.texts_to_sequences(val_texts))

        train_ds = TweetDataset(train_seqs, y_train)
        val_ds = TweetDataset(val_seqs, y_val)

        train_loader = DataLoader(train_ds, batch_size=self.batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=self.batch_size, shuffle=False)

        # Initialize BiLSTM
        self.model = BiLSTMSentimentClassifier(
            vocab_size=vocab_size,
            embed_dim=self.embed_dim,
            hidden_dim=self.hidden_dim,
            num_classes=3,
            dropout_rate=0.3
        ).to(self.device)

        # Handle class imbalance in loss function
        class_counts = np.bincount(y_train)
        weights = 1.0 / (class_counts / class_counts.sum())
        weights = weights / weights.sum()
        class_weights = torch.tensor(weights, dtype=torch.float).to(self.device)
        criterion = nn.CrossEntropyLoss(weight=class_weights)

        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=1e-5)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=0.5, patience=2)

        best_val_f1 = 0.0
        best_state_dict = None

        print("\nStarting Bi-Directional LSTM Neural Training...")
        for epoch in range(1, self.epochs + 1):
            self.model.train()
            total_loss = 0.0
            
            for seqs, labels in train_loader:
                seqs, labels = seqs.to(self.device), labels.to(self.device)
                optimizer.zero_grad()
                logits = self.model(seqs)
                loss = criterion(logits, labels)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=4.0)
                optimizer.step()
                total_loss += loss.item() * len(labels)
                
            train_loss = total_loss / len(train_loader.dataset)

            # Validation
            self.model.eval()
            val_preds, val_targets = [], []
            with torch.no_grad():
                for seqs, labels in val_loader:
                    seqs = seqs.to(self.device)
                    logits = self.model(seqs)
                    preds = torch.argmax(logits, dim=1).cpu().numpy()
                    val_preds.extend(preds)
                    val_targets.extend(labels.numpy())

            val_acc = accuracy_score(val_targets, val_preds)
            val_f1 = f1_score(val_targets, val_preds, average="macro")
            scheduler.step(val_f1)

            print(f"Epoch [{epoch}/{self.epochs}] - Train Loss: {train_loss:.4f} | Val Acc: {val_acc:.4f} | Val Macro-F1: {val_f1:.4f}")

            if val_f1 > best_val_f1:
                best_val_f1 = val_f1
                best_state_dict = self.model.state_dict().copy()

        if best_state_dict is not None:
            self.model.load_state_dict(best_state_dict)
            print(f"Restored best checkpoint with Validation Macro-F1: {best_val_f1:.4f}")

    def evaluate(self, test_texts: List[str], y_test: np.ndarray, target_names: list) -> Dict[str, Any]:
        self.model.eval()
        test_seqs = self.tokenizer.pad_sequences(self.tokenizer.texts_to_sequences(test_texts))
        test_ds = TweetDataset(test_seqs, y_test)
        test_loader = DataLoader(test_ds, batch_size=self.batch_size, shuffle=False)

        preds_list, probs_list = [], []
        with torch.no_grad():
            for seqs, _ in test_loader:
                seqs = seqs.to(self.device)
                logits = self.model(seqs)
                probs = torch.softmax(logits, dim=1).cpu().numpy()
                preds = np.argmax(probs, axis=1)
                preds_list.extend(preds)
                probs_list.extend(probs)

        preds_arr = np.array(preds_list)
        probs_arr = np.array(probs_list)

        acc = accuracy_score(y_test, preds_arr)
        f1_macro = f1_score(y_test, preds_arr, average="macro")
        f1_weighted = f1_score(y_test, preds_arr, average="weighted")
        cm = confusion_matrix(y_test, preds_arr)
        report = classification_report(y_test, preds_arr, target_names=target_names, output_dict=True)

        return {
            "model_name": "Bi-Directional LSTM (Deep Learning)",
            "accuracy": float(acc),
            "f1_macro": float(f1_macro),
            "f1_weighted": float(f1_weighted),
            "confusion_matrix": cm.tolist(),
            "classification_report": report,
            "predictions": preds_arr,
            "probabilities": probs_arr
        }

    def predict_single(self, text: str) -> Tuple[int, np.ndarray]:
        self.model.eval()
        seq = self.tokenizer.pad_sequences(self.tokenizer.texts_to_sequences([text]))
        tensor_seq = torch.tensor(seq, dtype=torch.long).to(self.device)
        with torch.no_grad():
            logits = self.model(tensor_seq)
            probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
            pred = int(np.argmax(probs))
        return pred, probs

    def save(self, output_dir: str):
        os.makedirs(output_dir, exist_ok=True)
        self.tokenizer.save(os.path.join(output_dir, "lstm_tokenizer.json"))
        torch.save(self.model.state_dict(), os.path.join(output_dir, "bilstm_weights.pt"))
        # Save model config
        config = {
            "vocab_size": len(self.tokenizer.word2idx),
            "embed_dim": self.embed_dim,
            "hidden_dim": self.hidden_dim,
            "max_len": self.max_len
        }
        with open(os.path.join(output_dir, "lstm_config.json"), "w") as f:
            json.dump(config, f)
        print(f"BiLSTM model saved to {output_dir}")

    @classmethod
    def load(cls, output_dir: str):
        with open(os.path.join(output_dir, "lstm_config.json"), "r") as f:
            cfg = json.load(f)
        trainer = cls(
            max_words=cfg["vocab_size"],
            max_len=cfg["max_len"],
            embed_dim=cfg["embed_dim"],
            hidden_dim=cfg["hidden_dim"]
        )
        trainer.tokenizer = TextTokenizer.load(os.path.join(output_dir, "lstm_tokenizer.json"))
        trainer.model = BiLSTMSentimentClassifier(
            vocab_size=cfg["vocab_size"],
            embed_dim=cfg["embed_dim"],
            hidden_dim=cfg["hidden_dim"]
        )
        trainer.model.load_state_dict(torch.load(os.path.join(output_dir, "bilstm_weights.pt"), map_location=torch.device("cpu")))
        trainer.model.eval()
        return trainer
