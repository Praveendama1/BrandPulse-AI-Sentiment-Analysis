"""
classical_model.py - Classical Statistical NLP Pipeline for BrandPulse AI
Implements TF-IDF Vectorization, Logistic Regression, Naive Bayes,
and Explainable AI (XAI) feature keyword attribution.
"""

import os
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Tuple, Any, List
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score


class ClassicalSentimentPipeline:
    """
    Classical NLP pipeline combining TF-IDF and Logistic Regression with Explainable AI.
    """

    def __init__(self, max_features: int = 5000, ngram_range: Tuple[int, int] = (1, 2)):
        self.max_features = max_features
        self.ngram_range = ngram_range
        self.vectorizer = TfidfVectorizer(
            max_features=self.max_features,
            ngram_range=self.ngram_range,
            sublinear_tf=True,
            min_df=2
        )
        self.model = LogisticRegression(
            max_iter=1000,
            C=1.5,
            class_weight="balanced",
            random_state=42
        )
        self.nb_model = MultinomialNB()

    def fit(self, train_texts: pd.Series, y_train: np.ndarray):
        X_train_vec = self.vectorizer.fit_transform(train_texts)
        self.model.fit(X_train_vec, y_train)
        self.nb_model.fit(X_train_vec, y_train)
        return self

    def evaluate(self, test_texts: pd.Series, y_test: np.ndarray, target_names: list) -> Dict[str, Any]:
        X_test_vec = self.vectorizer.transform(test_texts)
        y_pred = self.model.predict(X_test_vec)
        y_prob = self.model.predict_proba(X_test_vec)
        
        acc = accuracy_score(y_test, y_pred)
        f1_macro = f1_score(y_test, y_pred, average="macro")
        f1_weighted = f1_score(y_test, y_pred, average="weighted")
        cm = confusion_matrix(y_test, y_pred)
        report = classification_report(y_test, y_pred, target_names=target_names, output_dict=True)
        
        return {
            "model_name": "TF-IDF + Logistic Regression (Classical)",
            "accuracy": float(acc),
            "f1_macro": float(f1_macro),
            "f1_weighted": float(f1_weighted),
            "confusion_matrix": cm.tolist(),
            "classification_report": report
        }

    def predict_single(self, text: str) -> Tuple[int, np.ndarray]:
        vec = self.vectorizer.transform([text])
        pred = self.model.predict(vec)[0]
        prob = self.model.predict_proba(vec)[0]
        return int(pred), prob

    def explain_prediction(self, text: str) -> Dict[str, Any]:
        """
        Explainable AI: Identifies exact keyword drivers, polarity score (-1 to +1),
        and confidence calibration.
        """
        vec = self.vectorizer.transform([text])
        pred = int(self.model.predict(vec)[0])
        probs = self.model.predict_proba(vec)[0]
        
        # Calculate continuous polarity score (-1.0 to +1.0)
        # 0: negative, 1: neutral, 2: positive
        polarity = float(probs[2] - probs[0])  # P(Positive) - P(Negative)

        # Extract top driving keywords
        feature_names = self.vectorizer.get_feature_names_out()
        row = vec.tocoo()
        drivers = []
        for idx in row.col:
            word = feature_names[idx]
            weight = float(self.model.coef_[pred, idx] * vec[0, idx])
            drivers.append({"word": word, "impact": weight})

        drivers = sorted(drivers, key=lambda x: abs(x["impact"]), reverse=True)

        labels = {0: "NEGATIVE", 1: "NEUTRAL", 2: "POSITIVE"}
        sentiment = labels[pred]
        conf = float(probs[pred])

        if conf >= 0.80:
            intensity = "High Conviction"
        elif conf >= 0.55:
            intensity = "Moderate Conviction"
        else:
            intensity = "Mild / Ambiguous"

        return {
            "sentiment": sentiment,
            "pred_idx": pred,
            "confidence": conf,
            "confidence_pct": round(conf * 100, 1),
            "polarity": round(polarity, 2),
            "intensity": intensity,
            "probabilities": {
                "negative": round(float(probs[0]), 3),
                "neutral": round(float(probs[1]), 3),
                "positive": round(float(probs[2]), 3)
            },
            "top_drivers": drivers[:5]
        }

    def save(self, output_dir: str):
        os.makedirs(output_dir, exist_ok=True)
        joblib.dump(self.vectorizer, os.path.join(output_dir, "tfidf_vectorizer.joblib"))
        joblib.dump(self.model, os.path.join(output_dir, "logistic_regression.joblib"))

    @classmethod
    def load(cls, output_dir: str):
        pipeline = cls()
        pipeline.vectorizer = joblib.load(os.path.join(output_dir, "tfidf_vectorizer.joblib"))
        pipeline.model = joblib.load(os.path.join(output_dir, "logistic_regression.joblib"))
        return pipeline
