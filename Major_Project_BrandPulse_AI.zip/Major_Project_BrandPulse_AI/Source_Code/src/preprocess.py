"""
preprocess.py - Text Cleaning and Normalization Pipeline for BrandPulse AI
Handles Noise Removal, Lowercasing, Lemmatization, and Stopwords Filtering.
"""

import os
import re
import html
import sys
from typing import List, Tuple, Optional
import pandas as pd

# Add packages and nltk_data paths
base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(base_dir, "packages"))

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Configure NLTK data path
nltk_data_dir = os.path.join(base_dir, "nltk_data")
if os.path.exists(nltk_data_dir) and nltk_data_dir not in nltk.data.path:
    nltk.data.path.insert(0, nltk_data_dir)

try:
    lemmatizer = WordNetLemmatizer()
    # Retain sentiment-critical negation words in stopwords
    default_stop_words = set(stopwords.words("english"))
    negation_words = {"not", "no", "nor", "neither", "never", "none", "cannot", "hardly", "barely", "scarcely"}
    stop_words = default_stop_words - negation_words
except Exception as e:
    lemmatizer = None
    stop_words = set()


# Label Mappings (3-class Sentiment)
LABEL2INT = {"negative": 0, "neutral": 1, "positive": 2}
INT2LABEL = {0: "negative", 1: "neutral", 2: "positive"}


def clean_text_pipeline(text: str, lemmatize: bool = True, remove_stops: bool = True) -> str:
    """
    Standard NLP Cleaning Pipeline:
    1. Unescape HTML entities (&amp;, &lt;, etc.)
    2. Strip URLs (http://..., https://..., etc.)
    3. Strip user mentions (@user)
    4. Strip hashtag symbols (#word -> word)
    5. Strip numbers and non-letter noise
    6. Normalize whitespace and lowercase
    7. Linguistic processing: Lemmatization and Stop Words removal
    """
    if not isinstance(text, str):
        return ""
    
    # HTML unescape
    text = html.unescape(text)
    
    # Strip URLs
    text = re.sub(r"https?://\S+|www\.\S+|twitpic\.\S+|pic\.twitter\.\S+", "", text)
    
    # Strip user mentions (@username)
    text = re.sub(r"@\w+", "", text)
    
    # Replace hashtag symbol with word itself
    text = re.sub(r"#(\w+)", r"\1", text)
    
    # Keep only letters, whitespace, and basic apostrophes
    text = re.sub(r"[^a-zA-Z\s']", " ", text)
    
    # Lowercase
    tokens = text.lower().split()
    
    cleaned_tokens = []
    for token in tokens:
        # Strip trailing/leading apostrophes
        token = token.strip("'")
        if len(token) <= 1:
            continue
        
        # Stop word removal
        if remove_stops and token in stop_words:
            continue
            
        # Lemmatization (verb + noun)
        if lemmatize and lemmatizer:
            try:
                token = lemmatizer.lemmatize(token, pos="v")
                token = lemmatizer.lemmatize(token, pos="n")
            except Exception:
                pass
                
        cleaned_tokens.append(token)
        
    return " ".join(cleaned_tokens)


def load_and_preprocess_dataset(csv_path: str) -> pd.DataFrame:
    """
    Loads Twitter Airline dataset, handles 3 classes, cleans timestamps,
    and returns sanitized DataFrame.
    """
    df = pd.read_csv(csv_path)
    
    # Filter valid rows
    df = df.dropna(subset=["text", "airline_sentiment"]).copy()
    df = df[df["airline_sentiment"].isin(["negative", "neutral", "positive"])].copy()
    
    # Label encoding
    df["label"] = df["airline_sentiment"].map(LABEL2INT)
    
    # Parse timestamp for BrandPulse AI trend line
    if "tweet_created" in df.columns:
        df["tweet_created"] = pd.to_datetime(df["tweet_created"], errors="coerce")
    
    # Clean text
    print("Running text normalization, noise removal, and lemmatization...")
    df["clean_text"] = df["text"].apply(clean_text_pipeline)
    
    # Filter empty texts
    df = df[df["clean_text"].str.len() >= 2].copy().reset_index(drop=True)
    
    print(f"Dataset ready: {len(df)} tweets processed.")
    print("Class Distribution:")
    print(df["airline_sentiment"].value_counts())
    
    return df
