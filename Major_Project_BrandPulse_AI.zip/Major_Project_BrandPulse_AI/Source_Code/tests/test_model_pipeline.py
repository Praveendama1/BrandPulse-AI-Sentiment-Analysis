"""
test_model_pipeline.py - Comprehensive Test Suite for BrandPulse AI
Tests Preprocessing, Classical Pipeline, BiLSTM Deep Learning Model,
and Edge Cases (Negations, Sarcasm, Factual Inquiries, Out-of-Vocabulary).
"""

import os
import sys
import unittest
import numpy as np

# Setup paths
base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(base_dir, "packages"))
sys.path.insert(0, base_dir)

from src.preprocess import clean_text_pipeline, INT2LABEL, LABEL2INT
from src.classical_model import ClassicalSentimentPipeline
from src.deep_learning_lstm import DeepLearningTrainer


class TestBrandPulseAI(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        models_dir = os.path.join(base_dir, "models")
        cls.classical_model = ClassicalSentimentPipeline.load(models_dir)
        cls.lstm_model = DeepLearningTrainer.load(models_dir)

    def test_01_preprocessing_pipeline(self):
        """Test URL, mention, hashtag, and punctuation stripping with lemmatization."""
        raw_text = "Hey @VirginAmerica, check http://flight.com/status #delayed! It's running late..."
        cleaned = clean_text_pipeline(raw_text)
        
        # Verify URLs and mentions are removed
        self.assertNotIn("http", cleaned)
        self.assertNotIn("@virginamerica", cleaned)
        self.assertNotIn("#", cleaned)
        # Verify lemmatization: 'running' -> 'run'
        self.assertIn("run", cleaned)

    def test_02_preservation_of_negation_words(self):
        """Crucial NLP Test: Negations like 'not', 'no', 'never' must NOT be discarded by stop words."""
        negation_text = "The food was not good and never arrived on time."
        cleaned = clean_text_pipeline(negation_text)
        self.assertIn("not", cleaned)
        self.assertIn("never", cleaned)

    def test_03_custom_case_positive_praise(self):
        """Test Case: 'The service was amazing!' -> Positive sentiment."""
        text = "The service was amazing! Friendly crew and fast boarding."
        cleaned = clean_text_pipeline(text)
        
        c_pred, c_probs = self.classical_model.predict_single(cleaned)
        l_pred, l_probs = self.lstm_model.predict_single(cleaned)

        self.assertEqual(INT2LABEL[c_pred], "positive")
        self.assertEqual(INT2LABEL[l_pred], "positive")
        self.assertGreater(c_probs[LABEL2INT["positive"]], 0.70)
        self.assertGreater(l_probs[LABEL2INT["positive"]], 0.70)

    def test_04_custom_case_severe_complaint(self):
        """Test Case: 'I waited 4 hours just to get a cold burger.' -> Negative sentiment."""
        text = "I waited 4 hours just to get a cold burger. Disastrous customer care."
        cleaned = clean_text_pipeline(text)
        
        c_pred, c_probs = self.classical_model.predict_single(cleaned)
        l_pred, l_probs = self.lstm_model.predict_single(cleaned)

        self.assertEqual(INT2LABEL[c_pred], "negative")
        self.assertEqual(INT2LABEL[l_pred], "negative")
        self.assertGreater(c_probs[LABEL2INT["negative"]], 0.70)
        self.assertGreater(l_probs[LABEL2INT["negative"]], 0.70)

    def test_05_custom_case_lost_baggage(self):
        """Test Case: Lost luggage & rude staff -> Negative sentiment."""
        text = "Not happy with the rude agent at baggage claim, worst experience ever."
        cleaned = clean_text_pipeline(text)
        
        c_pred, _ = self.classical_model.predict_single(cleaned)
        l_pred, _ = self.lstm_model.predict_single(cleaned)

        self.assertEqual(INT2LABEL[c_pred], "negative")
        self.assertEqual(INT2LABEL[l_pred], "negative")

    def test_06_custom_case_smooth_flight_gratitude(self):
        """Test Case: Gratitude and smooth flight -> Positive sentiment."""
        text = "Thank you @VirginAmerica for a wonderfully smooth flight!"
        cleaned = clean_text_pipeline(text)
        
        c_pred, _ = self.classical_model.predict_single(cleaned)
        l_pred, _ = self.lstm_model.predict_single(cleaned)

        self.assertEqual(INT2LABEL[c_pred], "positive")
        self.assertEqual(INT2LABEL[l_pred], "positive")

    def test_07_probability_distribution_integrity(self):
        """Verify that probability distributions sum to 1.0 (valid probability simplex)."""
        text = "Flight 402 is delayed by 30 mins due to weather."
        cleaned = clean_text_pipeline(text)
        
        _, c_probs = self.classical_model.predict_single(cleaned)
        _, l_probs = self.lstm_model.predict_single(cleaned)

        self.assertAlmostEqual(float(np.sum(c_probs)), 1.0, places=4)
        self.assertAlmostEqual(float(np.sum(l_probs)), 1.0, places=4)

    def test_08_out_of_vocabulary_robustness(self):
        """Verify model handles rare slang, unknown tokens, and gibberish gracefully."""
        gibberish = "xyzzy zzzzzqw qwerty asdfgh"
        cleaned = clean_text_pipeline(gibberish)
        
        # Models should not crash on OOV tokens
        c_pred, c_probs = self.classical_model.predict_single(cleaned)
        l_pred, l_probs = self.lstm_model.predict_single(cleaned)
        
        self.assertIn(c_pred, [0, 1, 2])
        self.assertIn(l_pred, [0, 1, 2])


if __name__ == "__main__":
    unittest.main(verbosity=2)
