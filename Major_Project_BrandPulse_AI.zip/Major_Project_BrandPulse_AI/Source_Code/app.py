"""
app.py - BrandPulse AI: Live Sentiment Analytics & Twitter Brand Reputation Dashboard
Optimized for high-speed, decisive, and explainable sentiment classification.
"""

import os
import sys
import time
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st

# Environment & local paths
base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(base_dir, "packages"))
sys.path.insert(0, base_dir)

from src.preprocess import clean_text_pipeline, INT2LABEL, LABEL2INT
from src.classical_model import ClassicalSentimentPipeline
from src.deep_learning_lstm import DeepLearningTrainer
from src.reverse_engineering import ReverseEngineeringSuite
from src.selective_rag import KnowledgeBaseRetriever, IBMSelectiveRAGGate

# Page Configuration
st.set_page_config(
    page_title="BrandPulse AI | Twitter Sentiment Platform",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling for clear, crisp answers
st.markdown("""
<style>
    .verdict-box {
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 16px;
        color: white;
        text-align: center;
    }
    .verdict-pos { background: linear-gradient(135deg, #16a34a, #15803d); }
    .verdict-neg { background: linear-gradient(135deg, #dc2626, #b91c1c); }
    .verdict-neu { background: linear-gradient(135deg, #d97706, #b45309); }
    .driver-tag {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 6px;
        background: #f1f5f9;
        color: #0f172a;
        margin: 4px;
        font-size: 13px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_models():
    models_dir = os.path.join(base_dir, "models")
    classical = ClassicalSentimentPipeline.load(models_dir)
    lstm = DeepLearningTrainer.load(models_dir)
    return classical, lstm


@st.cache_resource
def load_rag_gate():
    kb_path = os.path.join(base_dir, "data", "knowledge_base")
    retriever = KnowledgeBaseRetriever(kb_path)
    gate = IBMSelectiveRAGGate(retriever, hallucination_threshold=0.15)
    return gate


def get_prediction_explanation(classical_model, cleaned_text: str):
    """
    Robust feature attribution and prediction explainability helper.
    """
    if hasattr(classical_model, "explain_prediction"):
        try:
            return classical_model.explain_prediction(cleaned_text)
        except Exception:
            pass

    vec = classical_model.vectorizer.transform([cleaned_text])
    pred = int(classical_model.model.predict(vec)[0])
    probs = classical_model.model.predict_proba(vec)[0]
    polarity = float(probs[2] - probs[0])

    feature_names = classical_model.vectorizer.get_feature_names_out()
    row = vec.tocoo()
    drivers = []
    for idx in row.col:
        word = feature_names[idx]
        weight = float(classical_model.model.coef_[pred, idx] * vec[0, idx])
        drivers.append({"word": word, "impact": weight})

    drivers = sorted(drivers, key=lambda x: abs(x["impact"]), reverse=True)
    labels = {0: "NEGATIVE", 1: "NEUTRAL", 2: "POSITIVE"}
    sentiment = labels[pred]
    conf = float(probs[pred])
    intensity = "High Conviction" if conf >= 0.80 else ("Moderate Conviction" if conf >= 0.55 else "Mild / Ambiguous")

    return {
        "sentiment": sentiment,
        "pred_idx": pred,
        "confidence": conf,
        "confidence_pct": round(conf * 100, 1),
        "polarity": round(polarity, 2),
        "intensity": intensity,
        "probabilities": {
            "negative": round(float(probs[0]), 3),
            "neutral": round(float(probs[1]), 3),
            "positive": round(float(probs[2]), 3)
        },
        "top_drivers": drivers[:5]
    }


@st.cache_data
def load_data():
    clean_csv = os.path.join(base_dir, "data", "cleaned_tweets.csv")
    if os.path.exists(clean_csv):
        df = pd.read_csv(clean_csv)
    else:
        df = pd.read_csv(os.path.join(base_dir, "data", "Tweets.csv"))
    if "tweet_created" in df.columns:
        df["tweet_created"] = pd.to_datetime(df["tweet_created"], errors="coerce")
    return df


def main():
    st.title("⚡ BrandPulse AI — Voice of the Customer Intelligence")
    st.caption("Automated Real-Time Social Media Emotion Understanding with Explainable NLP")

    classical_model, lstm_model = load_models()
    df_tweets = load_data()

    # Sidebar
    st.sidebar.title("BrandPulse AI Controls")
    selected_brand = st.sidebar.selectbox(
        "Filter by Airline / Brand:",
        ["All Airlines"] + sorted(df_tweets["airline"].dropna().unique().tolist())
    )
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("**Active Engine:**")
    st.sidebar.markdown("✔ **Fast Statistical Engine** (TF-IDF + LogReg)")
    st.sidebar.markdown("✔ **Deep Learning Engine** (Bi-Directional LSTM)")
    st.sidebar.caption("Both models run in parallel to give transparent, clear answers.")

    # Filtered dataset
    filtered_df = df_tweets if selected_brand == "All Airlines" else df_tweets[df_tweets["airline"] == selected_brand]

    # Metrics Row
    total_tweets = len(filtered_df)
    counts = filtered_df["airline_sentiment"].value_counts()
    neg_pct = (counts.get("negative", 0) / total_tweets) * 100 if total_tweets else 0
    neu_pct = (counts.get("neutral", 0) / total_tweets) * 100 if total_tweets else 0
    pos_pct = (counts.get("positive", 0) / total_tweets) * 100 if total_tweets else 0

    kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
    kpi1.metric("Analyzed Tweets", f"{total_tweets:,}")
    kpi2.metric("Negative", f"{neg_pct:.1f}%")
    kpi3.metric("Neutral", f"{neu_pct:.1f}%")
    kpi4.metric("Positive", f"{pos_pct:.1f}%")
    kpi5.metric("Net Sentiment Score", f"{pos_pct - neg_pct:+.1f}")

    # Tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🧪 Decisive Sentiment Tester (Clear Answers)",
        "📊 Live Stream & Emotion Trends",
        "⚖️ Benchmark & Engineering Report",
        "🕵️ Reverse Engineering & Probing",
        "🤖 IBM-Style Selective RAG"
    ])

    # ---------------- TAB 1: DECISIVE TESTER ----------------
    with tab1:
        st.subheader("🎯 Crystal-Clear Sentiment & Keyword Attribution")
        st.write("Type any custom tweet or customer comment below to receive an instant, decisive classification with highlighted trigger keywords.")

        # Preset Buttons
        p_col1, p_col2, p_col3 = st.columns(3)
        if p_col1.button("✨ Positive: 'The service was amazing!'"):
            st.session_state["query_text"] = "The service was amazing! Friendly crew and fast boarding."
        if p_col2.button("😡 Negative: 'Waited 4 hours for cold burger'"):
            st.session_state["query_text"] = "I waited 4 hours just to get a cold burger. Disastrous customer care."
        if p_col3.button("ℹ️ Neutral: 'Flight 402 departure gate'"):
            st.session_state["query_text"] = "What is the departure gate for flight 402 to Chicago?"

        input_text = st.text_area(
            "Enter Tweet Text:",
            value=st.session_state.get("query_text", "The flight attendants were extremely courteous, attentive, and made our journey delightful!"),
            height=90
        )

        if st.button("🚀 Analyze Sentiment Now", type="primary"):
            t_start = time.perf_counter()
            cleaned = clean_text_pipeline(input_text)
            explanation = get_prediction_explanation(classical_model, cleaned)
            l_pred, l_probs = lstm_model.predict_single(cleaned)
            t_elapsed_ms = (time.perf_counter() - t_start) * 1000

            # 1. Clear Decision Banner
            sent = explanation["sentiment"]
            box_cls = "verdict-pos" if sent == "POSITIVE" else ("verdict-neg" if sent == "NEGATIVE" else "verdict-neu")
            icon = "😊" if sent == "POSITIVE" else ("😡" if sent == "NEGATIVE" else "ℹ️")

            st.markdown(f"""
            <div class="verdict-box {box_cls}">
                <h1 style="margin:0; font-size: 32px;">{icon} VERDICT: {sent}</h1>
                <h3 style="margin:4px 0 0 0; opacity: 0.95;">{explanation['confidence_pct']}% Confidence • {explanation['intensity']}</h3>
                <p style="margin:6px 0 0 0; font-size: 14px; opacity: 0.85;">Inference completed in <b>{t_elapsed_ms:.1f} ms</b></p>
            </div>
            """, unsafe_allow_html=True)

            # 2. Detailed Dual-Model Verification & Explainability
            res_left, res_right = st.columns(2)

            with res_left:
                st.markdown("#### 🔍 Explainable Keyword Drivers (Why the model decided this)")
                st.write(f"**Cleaned Tokens:** `{cleaned}`")
                
                if explanation["top_drivers"]:
                    st.write("Key words contributing to this decision:")
                    for driver in explanation["top_drivers"]:
                        sign = "+" if driver["impact"] > 0 else "-"
                        st.markdown(f"<span class='driver-tag'>🏷️ <b>{driver['word']}</b> ({sign}{abs(driver['impact']):.2f} impact)</span>", unsafe_allow_html=True)
                else:
                    st.info("No strong sentiment polarity keywords detected (Neutral / Factual inquiry).")

                st.markdown("---")
                st.write(f"**Polarity Score:** `{explanation['polarity']:+.2f}` (Range: -1.0 to +1.0)")
                # Normalized polarity to 0..1 for progress bar
                norm_polarity = (explanation['polarity'] + 1.0) / 2.0
                st.progress(float(norm_polarity))
                st.caption("Negative (-1.0) ← Neutral (0.0) → Positive (+1.0)")

            with res_right:
                st.markdown("#### ⚖️ Dual-Model Probability Breakdown")
                
                st.markdown("**Classical Model (TF-IDF + Logistic Regression):**")
                c_p = explanation["probabilities"]
                st.write(f"• Negative: **{c_p['negative']*100:.1f}%**")
                st.write(f"• Neutral: **{c_p['neutral']*100:.1f}%**")
                st.write(f"• Positive: **{c_p['positive']*100:.1f}%**")

                st.markdown("**Deep Learning Model (Bi-Directional LSTM):**")
                st.write(f"• Negative: **{l_probs[0]*100:.1f}%**")
                st.write(f"• Neutral: **{l_probs[1]*100:.1f}%**")
                st.write(f"• Positive: **{l_probs[2]*100:.1f}%**")
                
                # Agreement check
                if explanation["pred_idx"] == l_pred:
                    st.success("✅ Both Classical and Deep Learning models are in 100% agreement!")
                else:
                    st.warning(f"⚠️ Context nuance: Classical predicts {sent}, BiLSTM predicts {INT2LABEL[l_pred].upper()}.")

    # ---------------- TAB 2: LIVE STREAM & TRENDS ----------------
    with tab2:
        st.subheader("Live Tweet Stream Simulation & Emotion Trends")
        c1, c2 = st.columns([1, 1])

        with c1:
            st.markdown("#### Sentiment Distribution")
            fig, ax = plt.subplots(figsize=(4.5, 4.5))
            ax.pie(
                [counts.get("negative", 0), counts.get("neutral", 0), counts.get("positive", 0)],
                labels=["Negative", "Neutral", "Positive"],
                autopct="%1.1f%%",
                startangle=140,
                colors=["#ef4444", "#f59e0b", "#22c55e"],
                wedgeprops=dict(width=0.45, edgecolor="w")
            )
            ax.set_title(f"Brand Sentiment: {selected_brand}", fontweight="bold")
            st.pyplot(fig)

        with c2:
            st.markdown("#### 24-Hour Temporal Trend Line")
            if "tweet_created" in filtered_df.columns and not filtered_df["tweet_created"].isna().all():
                trend_df = filtered_df.copy()
                trend_df["time_bin"] = trend_df["tweet_created"].dt.floor("4h")
                trend_pivot = trend_df.groupby(["time_bin", "airline_sentiment"]).size().unstack(fill_value=0)
                st.line_chart(trend_pivot)

        st.markdown("---")
        st.markdown("#### 🔴 Live Incoming Tweet Feed Sample")
        sample_batch = filtered_df.sample(n=min(len(filtered_df), 5), random_state=42)
        for _, row in sample_batch.iterrows():
            text = row["text"]
            cln = clean_text_pipeline(text)
            p_idx, pr = classical_model.predict_single(cln)
            s_name = INT2LABEL[p_idx].upper()
            color = "red" if p_idx == 0 else ("green" if p_idx == 2 else "blue")
            st.write(f":{color}[**{s_name}** ({pr[p_idx]*100:.0f}%)] — \"{text}\"")

    # ---------------- TAB 3: BENCHMARK & REPORT ----------------
    with tab3:
        st.subheader("Engineering Benchmark: Classical NLP vs Deep Learning")
        st.table(pd.DataFrame([
            {
                "Evaluation Dimension": "Overall Accuracy",
                "Classical (TF-IDF + LogReg)": "77.15%",
                "Deep Learning (BiLSTM)": "72.78%",
                "Advantage": "Classical (Higher keyword precision)"
            },
            {
                "Evaluation Dimension": "Macro F1-Score",
                "Classical (TF-IDF + LogReg)": "0.7216",
                "Deep Learning (BiLSTM)": "0.6905",
                "Advantage": "Classical (Balances imbalanced classes)"
            },
            {
                "Evaluation Dimension": "Inference Latency",
                "Classical (TF-IDF + LogReg)": "0.8 ms / tweet",
                "Deep Learning (BiLSTM)": "14.8 ms / tweet",
                "Advantage": "Classical (~18x faster)"
            },
            {
                "Evaluation Dimension": "Explainability",
                "Classical (TF-IDF + LogReg)": "100% Transparent (Feature Weights)",
                "Deep Learning (BiLSTM)": "Black-Box (Recurrent Gates)",
                "Advantage": "Classical"
            },
            {
                "Evaluation Dimension": "Sequential Context",
                "Classical (TF-IDF + LogReg)": "Limited to 2-word ngrams",
                "Deep Learning (BiLSTM)": "Full Bi-Directional Memory",
                "Advantage": "Deep Learning"
            }
        ]))

    # ---------------- TAB 4: REVERSE ENGINEERING & PROBING ----------------
    with tab4:
        st.subheader("🕵️ Reverse Engineering & Model Behavioral Probing")
        st.caption("Inspect the mathematical weights, probe word sensitivity, test adversarial attacks, and audit brand bias.")

        suite = ReverseEngineeringSuite(os.path.join(base_dir, "models"))

        # Section 1: Internal Weights
        st.markdown("### 1. Model Deconstruction: What Did the AI Learn?")
        st.write("Extracting the highest positive and negative mathematical weights directly from model parameters:")

        weights = suite.get_top_learned_weights(top_n=8)
        w_col1, w_col2, w_col3 = st.columns(3)

        with w_col1:
            st.markdown("**:red[Top Negative Signal Words:]**")
            for item in weights["negative"]:
                st.write(f"• `{item['word']}`: **{item['weight']:+.3f}**")

        with w_col2:
            st.markdown("**:blue[Top Neutral Signal Words:]**")
            for item in weights["neutral"]:
                st.write(f"• `{item['word']}`: **{item['weight']:+.3f}**")

        with w_col3:
            st.markdown("**:green[Top Positive Signal Words:]**")
            for item in weights["positive"]:
                st.write(f"• `{item['word']}`: **{item['weight']:+.3f}**")

        st.markdown("---")

        # Section 2: Word Occlusion
        st.markdown("### 2. Word Occlusion Probe (LIME-style Sensitivity)")
        st.write("Deletes each word one-by-one to measure exactly which word causes the largest emotional drop.")

        occl_input = st.text_input(
            "Enter sentence to probe for word sensitivity:",
            value="Thanks for the amazing crew but my bag was lost and the wait was terrible"
        )
        if st.button("🔬 Probe Word Sensitivity", key="btn_occl"):
            occl_res = suite.word_occlusion_test(occl_input)
            st.write(f"**Baseline Verdict:** {occl_res['classical_verdict']} ({occl_res['classical_conf']}%)")
            
            impact_df = pd.DataFrame(occl_res["word_impacts"])
            st.dataframe(impact_df, use_container_width=True)

        st.markdown("---")

        # Section 3: Adversarial Flip Attack
        st.markdown("### 3. Adversarial Attack Simulator (Can a 1-Word Edit Trick the AI?)")
        st.write("Tests if an angry complaint can trick the model into predicting POSITIVE by appending high-weight trigger words:")

        adv_input = st.text_input(
            "Enter negative complaint to test for adversarial vulnerability:",
            value="my flight was delayed and nobody helped"
        )
        if st.button("⚡ Test Adversarial Vulnerability", key="btn_adv"):
            flip_res = suite.test_adversarial_flips(adv_input)
            st.write(f"**Original Verdict:** :{ 'red' if flip_res['original_verdict'] == 'NEGATIVE' else 'blue' }[{flip_res['original_verdict']} ({flip_res['original_confidence']}%) ]")

            if flip_res["is_vulnerable"]:
                st.error("⚠️ Vulnerability Confirmed: The model's sentiment can be tricked by adding a single word!")
                for flip in flip_res["flips_found"]:
                    st.write(f"• Adding **`'{flip['trigger_word']}'`** flips sentiment to **:{ 'green' if flip['new_verdict'] == 'POSITIVE' else 'blue' }[{flip['new_verdict']} ({flip['new_confidence']}%) ]**")
            else:
                st.success("✅ Robust: No single word was able to flip this complaint!")

        st.markdown("---")

        # Section 4: Behavioral CheckList Probes
        st.markdown("### 4. Behavioral Stress Probes (CheckList Methodology)")
        st.write("Evaluating classical vs deep learning on Sarcasm, Negation, Typos, and Edge Cases:")

        if st.button("📋 Run Full Behavioral Probe Suite", key="btn_probes"):
            probes = suite.run_behavioral_probes()
            st.table(pd.DataFrame(probes))

        st.markdown("---")

        # Section 5: Brand Bias Audit
        st.markdown("### 5. Algorithmic Fairness & Airline Brand Bias Audit")
        st.write("Checks whether replacing the airline name (`@united` vs `@Delta` vs `@SouthwestAir`) changes the sentiment score on identical text:")
        
        bias_report = suite.probe_brand_bias()
        for tmpl, info in bias_report.items():
            status = "✅ 100% Fair / Unbiased" if info["is_unbiased"] else "❌ Brand Bias Detected"
            st.write(f"• Template `\"{tmpl}\"` $\\to$ **{status}**")

    # ---------------- TAB 5: IBM-STYLE SELECTIVE RAG ----------------
    with tab5:
        st.subheader("🤖 IBM-Style Selective RAG (Hallucination Reduction Engine)")
        st.markdown("""
        **How it works (IBM watsonx RAG Stack Architecture):**
        * **The Problem with Naive RAG**: Feeding documents into every query causes models to hallucinate when irrelevant chunks are retrieved.
        * **The IBM Solution**: The **Retrieval Gate** decides whether to search documents.
          * Pure emotional venting (*"I hate this airline"*) $\\to$ **DO NOT RETRIEVE** (Prevents hallucinating unrelated rules).
          * Factual / Policy inquiries (*"What is the carry-on limit?"*) $\\to$ **RETRIEVE & GROUND** in official airline policy.
        """)

        rag_gate = load_rag_gate()

        st.markdown("---")
        st.markdown("#### Test Selective Retrieval & Hallucination Prevention")

        rag_p1, rag_p2, rag_p3 = st.columns(3)
        if rag_p1.button("📋 Policy: 'Carry on luggage weight limit'"):
            st.session_state["rag_query"] = "What is the baggage weight limit for carry on luggage?"
        if rag_p2.button("⏱️ Complaint: 'Delayed 4 hours, meal vouchers?'"):
            st.session_state["rag_query"] = "Flight delayed by 4 hours, do you provide meal vouchers or refunds?"
        if rag_p3.button("😡 Venting: 'Worst airline, hate the service!'"):
            st.session_state["rag_query"] = "I hate this airline so much, worst service ever, total disaster!"

        rag_input = st.text_area(
            "Enter Customer Tweet / Inquiry:",
            value=st.session_state.get("rag_query", "What is the baggage weight limit for carry on luggage?"),
            height=85
        )

        if st.button("⚡ Run Selective RAG Triage", type="primary"):
            cleaned = clean_text_pipeline(rag_input)
            pred_idx, probs = classical_model.predict_single(cleaned)
            sent_name = INT2LABEL[pred_idx]
            sent_conf = probs[pred_idx] * 100

            rag_result = rag_gate.process_query(rag_input, sent_name, sent_conf)

            # Decision Cards
            dec_col1, dec_col2, dec_col3 = st.columns(3)
            
            with dec_col1:
                st.markdown("**1. Sentiment Engine**")
                s_color = "red" if sent_name == "negative" else ("green" if sent_name == "positive" else "blue")
                st.markdown(f":{s_color}[**{sent_name.upper()} ({sent_conf:.1f}%)**]")

            with dec_col2:
                st.markdown("**2. IBM Retrieval Gate Decision**")
                if "DO_NOT_RETRIEVE" in rag_result["gate_decision"]:
                    st.info(f"🚫 **DO NOT RETRIEVE** (Score: {rag_result['gate_score']})")
                else:
                    st.success(f"🔍 **RETRIEVE DOCUMENTS** (Score: {rag_result['gate_score']})")

            with dec_col3:
                st.markdown("**3. Hallucination Risk**")
                st.markdown(f"🛡️ **{rag_result['hallucination_risk']}**")

            st.markdown("---")
            st.markdown("#### 🎯 Grounded AI Response (Zero Hallucination Guarantee)")
            st.markdown(rag_result["final_response"])

            if rag_result.get("retrieved_documents"):
                st.markdown("---")
                st.markdown("#### 📄 Retrieved Enterprise Policy Citations")
                for doc in rag_result["retrieved_documents"]:
                    with st.expander(f"Source: {doc['source']} | Section: {doc['header']} (Relevance: {doc['relevance_score']})"):
                        st.code(doc["text"], language="markdown")


if __name__ == "__main__":
    main()
