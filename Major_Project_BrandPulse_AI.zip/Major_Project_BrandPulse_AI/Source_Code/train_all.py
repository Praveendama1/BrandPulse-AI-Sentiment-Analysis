"""
train_all.py - Complete Training & Comparative Evaluation Script for BrandPulse AI
Trains Classical (TF-IDF + Logistic Regression) and Deep Learning (BiLSTM) models,
generates performance comparison tables and confusion matrices.
"""

import os
import sys
import json
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# Setup environment
os.environ["MPLCONFIGDIR"] = "/tmp/matplotlib"
project_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(project_dir, "packages"))
sys.path.insert(0, project_dir)

from src.preprocess import load_and_preprocess_dataset, clean_text_pipeline, INT2LABEL
from src.classical_model import ClassicalSentimentPipeline
from src.deep_learning_lstm import DeepLearningTrainer


def plot_confusion_matrix(cm: np.ndarray, labels: list, title: str, save_path: str):
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=labels, yticklabels=labels)
    plt.title(title, fontsize=13, fontweight="bold")
    plt.xlabel("Predicted Sentiment")
    plt.ylabel("True Sentiment")
    plt.tight_layout()
    plt.savefig(save_path, dpi=200)
    plt.close()
    print(f"Saved confusion matrix: {save_path}")


def main():
    print("====================================================================")
    print("          BRANDPULSE AI: NLP SENTIMENT BENCHMARK PIPELINE          ")
    print("====================================================================")

    data_path = os.path.join(project_dir, "data", "Tweets.csv")
    models_dir = os.path.join(project_dir, "models")
    reports_dir = os.path.join(project_dir, "reports")
    static_dir = os.path.join(project_dir, "static")
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)
    os.makedirs(static_dir, exist_ok=True)

    # 1. Load and Preprocess Dataset
    df = load_and_preprocess_dataset(data_path)
    
    # Save cleaned dataset for notebooks and dashboard
    clean_csv = os.path.join(project_dir, "data", "cleaned_tweets.csv")
    df.to_csv(clean_csv, index=False)
    print(f"Cleaned dataset saved: {clean_csv}")

    # 2. Stratified Data Split (70% Train, 15% Validation, 15% Test)
    X = df["clean_text"]
    y = df["label"].values

    X_train_val, X_test, y_train_val, y_test = train_test_split(
        X, y, test_size=0.15, random_state=42, stratify=y
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_val, y_train_val, test_size=0.1765, random_state=42, stratify=y_train_val
    )  # 0.1765 of 0.85 ~ 0.15 of total

    print(f"\nData Splits: Train={len(X_train)} | Val={len(X_val)} | Test={len(X_test)}")
    target_names = ["Negative", "Neutral", "Positive"]

    # 3. Train Approach A: Classical NLP (TF-IDF + Logistic Regression)
    print("\n--------------------------------------------------------------------")
    print("           APPROACH A: CLASSICAL STATISTICAL NLP (TF-IDF)           ")
    print("--------------------------------------------------------------------")
    classical_pipe = ClassicalSentimentPipeline(max_features=5000)
    classical_pipe.fit(X_train, y_train)
    classical_results = classical_pipe.evaluate(X_test, y_test, target_names)
    classical_pipe.save(models_dir)

    print(f"Classical Accuracy: {classical_results['accuracy'] * 100:.2f}%")
    print(f"Classical Macro-F1: {classical_results['f1_macro']:.4f}")
    print(f"Classical Weighted-F1: {classical_results['f1_weighted']:.4f}")

    # Plot Classical Confusion Matrix
    cm_classical_path = os.path.join(static_dir, "confusion_matrix_classical.png")
    plot_confusion_matrix(
        np.array(classical_results["confusion_matrix"]),
        target_names,
        "Classical NLP Confusion Matrix (TF-IDF + LogReg)",
        cm_classical_path
    )

    # 4. Train Approach B: Deep Learning (Bi-Directional LSTM)
    print("\n--------------------------------------------------------------------")
    print("           APPROACH B: DEEP LEARNING (EMBEDDING + BiLSTM)           ")
    print("--------------------------------------------------------------------")
    lstm_trainer = DeepLearningTrainer(
        max_words=8000,
        max_len=60,
        embed_dim=128,
        hidden_dim=128,
        batch_size=64,
        lr=0.001,
        epochs=8
    )
    lstm_trainer.fit(
        train_texts=X_train.tolist(),
        y_train=y_train,
        val_texts=X_val.tolist(),
        y_val=y_val
    )
    lstm_results = lstm_trainer.evaluate(X_test.tolist(), y_test, target_names)
    lstm_trainer.save(models_dir)

    print(f"Deep Learning Accuracy: {lstm_results['accuracy'] * 100:.2f}%")
    print(f"Deep Learning Macro-F1: {lstm_results['f1_macro']:.4f}")
    print(f"Deep Learning Weighted-F1: {lstm_results['f1_weighted']:.4f}")

    # Plot LSTM Confusion Matrix
    cm_lstm_path = os.path.join(static_dir, "confusion_matrix_lstm.png")
    plot_confusion_matrix(
        np.array(lstm_results["confusion_matrix"]),
        target_names,
        "Deep Learning Confusion Matrix (BiLSTM)",
        cm_lstm_path
    )

    # 5. Comparative Evaluation Summary
    print("\n====================================================================")
    print("                    HEAD-TO-HEAD MODEL COMPARISON                   ")
    print("====================================================================")
    summary_df = pd.DataFrame([
        {
            "Model": "Approach A: TF-IDF + Logistic Regression",
            "Accuracy": f"{classical_results['accuracy'] * 100:.2f}%",
            "Macro F1": f"{classical_results['f1_macro']:.4f}",
            "Weighted F1": f"{classical_results['f1_weighted']:.4f}",
            "Inference Speed": "Ultra-Fast (~1ms)",
            "Interpretability": "High (Feature Weights)"
        },
        {
            "Model": "Approach B: Embedding + Bi-Directional LSTM",
            "Accuracy": f"{lstm_results['accuracy'] * 100:.2f}%",
            "Macro F1": f"{lstm_results['f1_macro']:.4f}",
            "Weighted F1": f"{lstm_results['f1_weighted']:.4f}",
            "Inference Speed": "Moderate (~15ms)",
            "Interpretability": "Black Box (Hidden States)"
        }
    ])
    print(summary_df.to_string(index=False))

    # Save metrics JSON
    metrics_export = {
        "classical": {
            "accuracy": classical_results["accuracy"],
            "f1_macro": classical_results["f1_macro"],
            "f1_weighted": classical_results["f1_weighted"],
            "confusion_matrix": classical_results["confusion_matrix"],
            "classification_report": classical_results["classification_report"]
        },
        "deep_learning_lstm": {
            "accuracy": lstm_results["accuracy"],
            "f1_macro": lstm_results["f1_macro"],
            "f1_weighted": lstm_results["f1_weighted"],
            "confusion_matrix": lstm_results["confusion_matrix"],
            "classification_report": lstm_results["classification_report"]
        }
    }
    with open(os.path.join(reports_dir, "metrics_comparison.json"), "w") as f:
        json.dump(metrics_export, f, indent=2)

    # 6. Test Inference with Required Custom Inputs
    test_queries = [
        "The service was amazing!",
        "I waited 4 hours just to get a cold burger.",
        "Flight 402 is delayed by 30 mins due to weather.",
        "Not happy with the rude agent at baggage claim, worst experience ever.",
        "Thank you @VirginAmerica for a wonderfully smooth flight!"
    ]
    print("\n====================================================================")
    print("              INFERENCE ON CUSTOM TEST SAMPLES                      ")
    print("====================================================================")
    for q in test_queries:
        clean_q = clean_text_pipeline(q)
        c_pred, c_prob = classical_pipe.predict_single(clean_q)
        l_pred, l_prob = lstm_trainer.predict_single(clean_q)
        print(f"Input: \"{q}\"")
        print(f" -> Classical LogReg : {INT2LABEL[c_pred].upper()} (Confidence: {c_prob[c_pred]*100:.1f}%)")
        print(f" -> Deep Learning LSTM: {INT2LABEL[l_pred].upper()} (Confidence: {l_prob[l_pred]*100:.1f}%)\n")

    print("Pipeline finished successfully!")


if __name__ == "__main__":
    main()
